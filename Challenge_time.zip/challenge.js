function chalenge_time() {
classtoString("challenge")
}